const express = require("express");
const axios = require("axios");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;

const GITHUB_TOKEN = "WSTAW_TUTAJ_NOWY_TOKEN";
const GIST_ID = "a8f3882d38ea24d574b14f330309d1cd";
const FILE_NAME = "logowanie_e2.json";

app.use(bodyParser.json());

app.post("/update-gist", async (req, res) => {
    const newContent = req.body.content;

    try {
        const response = await axios.patch(
            `https://api.github.com/gists/${GIST_ID}`,
            {
                files: {
                    [FILE_NAME]: {
                        content: newContent
                    }
                }
            },
            {
                headers: {
                    Authorization: `Bearer ${GITHUB_TOKEN}`,
                    "User-Agent": "GistUpdater"
                }
            }
        );

        res.json({ success: true, updated: response.data });
    } catch (error) {
        console.error("Błąd:", error.response?.data || error.message);
        res.status(500).json({ success: false, error: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`Serwer działa na porcie ${PORT}`);
});